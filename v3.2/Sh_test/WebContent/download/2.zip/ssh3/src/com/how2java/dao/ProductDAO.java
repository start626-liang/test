package com.how2java.dao;


import org.springframework.orm.hibernate3.HibernateTemplate;




public class ProductDAO extends HibernateTemplate{

	
}
